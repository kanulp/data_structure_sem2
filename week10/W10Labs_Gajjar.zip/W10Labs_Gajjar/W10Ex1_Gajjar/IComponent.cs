﻿using System;
namespace W10Ex1_Gajjar
{
    public interface IComponent
    {
        void listContactDetails();
    }
}
