﻿using System;

namespace W10Ex3_Gajjar
{
    public interface Logger
    {
        void log(string logMessage);
    }
}
