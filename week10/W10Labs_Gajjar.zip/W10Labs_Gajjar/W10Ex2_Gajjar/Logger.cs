﻿using System;
namespace W10Ex2_Gajjar
{
    public interface Logger
    {
        void log(string logMessage);
    }
}
